function one() {
	document.getElementById('blue').style.background = "red";
	document.getElementById('red').style.background = "green";
	document.getElementById('green').style.background = "blue";
}

function two() {
	document.getElementById('blue').style.height = "10px";
	document.getElementById('red').style.height = "60px";
	document.getElementById('green').style.height = "200px";
}

function three() {
	document.getElementById('blue').style.background = "red";
	document.getElementById('red').style.background = "green";
	document.getElementById('green').style.background = "blue";
	document.getElementById('blue').style.height = "180px";
	document.getElementById('red').style.height = "68px";
	document.getElementById('green').style.height = "25px";
}