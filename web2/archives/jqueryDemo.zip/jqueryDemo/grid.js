$(document).ready( function() {
	
	var container = $('section');
	
	var columns = 3;
	var rows = 4;
	
	var w = 100/columns;
	var h = 100/rows;
	
	var gridObjects = [
	{
		projectTitle:"My Design Project",
		dek:"This is my first project for class.",
		img:"imgs/amsler-grid.gif"
	},
	{
		projectTitle:"My Painting Project",
		dek:"This is a painting that I made.",
		img: "imgs/750px-Birds_painting.jpg"
	}
	];
	
	var colorArray = [
		"#47B3FF", 
		"#6E787F", 
		"#398FCC",  
		"#AADCFF",
		"#24597F"
	];
	
	for (var i = 0; i < columns*rows; i++) {
		var d = document.createElement('div');
		$(d).css({width:w+"%", height:h+"%"});
		$(d).addClass('module expand');
		$(d).css('background', colorArray[i%colorArray.length]);
		
		if (gridObjects[i] != null) {
			$(d).append('<img src="' + gridObjects[i].img +'">')
				.append('<h2>'+gridObjects[i].projectTitle+'</h2>')
				.append('<p>'+gridObjects[i].dek+'</p>')
				;
		}	
		container.append(d);
	}
	
	$('body').on('click', '.expand', function(){
		$(this).removeClass('expand');
		$(this).css({zIndex:1,position:'absolute'})
			.animate({
			width:'100%',
			height:'100%'
		}, 500);
		$(this).append('<div class="close"></div>');
	});
	
	$('body').on('click', '.close', function(){
		$(this).parent().addClass('expand');
		$(this).parent().css({zIndex:0,position:'relative'})
			.animate({
			width:w+'%',
			height:h+'%'
		}, 300);
		$(this).remove();
	});
	
});











