var video = document.getElementById('cat');
var play = document.getElementById('play');
var controls = document.getElementById('video-controls');
var playpause = document.getElementById('play-pause');

var isplaying = false;

play.addEventListener('click', function(){
	video.play();
	this.style.display = "none";
	controls.style.display = "block";
	isplaying = true;
	
});

video.addEventListener('ended', function(){
	isplaying = false;
	playpause.innerHTML = "Play";
	
});

playpause.addEventListener('click', function(){
	if (isplaying) {
		video.pause();
		playpause.innerHTML = "Play";
		isplaying = false;
	} else {
		video.play();
		playpause.innerHTML = "Pause";
		isplaying = true;
		
	}
});